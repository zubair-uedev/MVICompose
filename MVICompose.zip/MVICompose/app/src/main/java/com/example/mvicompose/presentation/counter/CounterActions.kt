package com.example.mvicompose.presentation.counter

sealed interface CounterActions {
    data object Increment: CounterActions
    data object Decrement: CounterActions
    data object Reset: CounterActions
}