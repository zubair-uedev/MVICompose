package com.example.mvicompose.presentation.counter

data class CounterUiState(
    val count: Int = 0
)
