package com.example.mvicompose.presentation.counter
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class CounterViewModel() : ViewModel() {
    private val _countState = MutableStateFlow<CounterUiState>(CounterUiState())
    val countState = _countState.asStateFlow()

    fun result(counterActions: CounterActions) {
        when (counterActions) {
            CounterActions.Decrement -> {
                _countState.update {
                    it.copy(count = it.count + 1)
                }
            }

            CounterActions.Increment -> {
                _countState.update {
                    it.copy(
                        count = it.count - 1
                    )
                }
            }

            CounterActions.Reset -> {
                _countState.update {
                    it.copy(
                        count = 0
                    )
                }
            }
        }
    }

}