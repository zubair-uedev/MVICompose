package com.example.mvicompose.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.mvicompose.presentation.dashboard.DashBoard
import com.example.mvicompose.presentation.onboard.OnBoardScreen
import com.example.mvicompose.presentation.spalsh.SplashScreen
import com.example.mvicompose.routes.Routes

@Composable
fun Navigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.SplashRoute) {
        composable<Routes.SplashRoute> {
            SplashScreen(goToSplash = {
                navController.navigate(Routes.OnBoardRoute)
            })
        }
        composable<Routes.OnBoardRoute> {
            OnBoardScreen(goToOnBoard = {
                navController.navigate(Routes.DashBoardRoute)
            })
        }
        composable<Routes.DashBoardRoute> {
            DashBoard()
        }
    }
}